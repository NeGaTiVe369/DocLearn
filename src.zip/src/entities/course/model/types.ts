export interface Course { 
  id: string
  title: string
  description: string
  duration: string
  students: number
  rating: number
  createdAt: string
}