import { CardGrid } from "@/widgets/CardGrid/ui/CardGrid/CardGrid"

export default function Home() {
  return (
    <main >
      <CardGrid />
    </main>
  )
}

