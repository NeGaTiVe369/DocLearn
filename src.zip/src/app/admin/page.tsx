import { AdminDashboard } from "@/widgets/admin-dashboard/ui/AdminDashboard"

export default function AdminPage() {
  return (
    <div style={{ marginTop: "7rem", marginBottom: "5rem" }}>
      <AdminDashboard />
    </div>
  )
}
