import { UnderDevelopment } from "@/shared/ui/UnderDevelopment/UnderDevelopment";

export default function NewsPage() {
  return (
    <div >
      <UnderDevelopment 
        title="Раздел 'Новости' в разработке"
        description="Мы готовим для вас новостной раздел"
      />
    </div>
  )
}


