import { UnderDevelopment } from "@/shared/ui/UnderDevelopment/UnderDevelopment";

export default function FeedPage() {
  return (
    <div >
      <UnderDevelopment 
        title="Лента публикаций в разработке"
        description="Мы готовим для вас ленту публикаций"
      />
    </div>
  )
}


