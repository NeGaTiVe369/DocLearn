import { UnderDevelopment } from "@/shared/ui/UnderDevelopment/UnderDevelopment";
//className="container mx-auto px-4 py-8"
export default function AggregatorPage() {
  return (
    <div> 
      <UnderDevelopment 
        title="Агрегатор в разработке"
        description="Мы готовим для вас агрегатор научных статей"
      />
    </div>
  )
}
